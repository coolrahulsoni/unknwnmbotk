/*Custom Js File */


/*For Login Page*/
// Shorthand for $( document ).ready()
$(function() {
    winHeight = $(window).height();
    winWidth = $(window).width();
    height1 = $('.height1').height();
   $('.login_Page').css('height',winHeight);
   $('.login_Page').css('width',winWidth);
  
    $('.select2select').select2();

   /*  //$('.height1 .container-fluid').css('height',height1);
   //$('.login_Page .row').css('height',winHeight);
   $('.login_body').ripples('updateSize')
*/


  footerBottom();
delete winHeight;
delete winWidth;
delete height1;
});

$('.icon1').hover(function(){
  $(this).removeClass('fadeInDown');
  $(this).toggleClass('pulse infinite');
})





$(window).resize(function() {
	var winHeight = $(window).height();
   var winWidth = $(window).width();
	 var height1 = $('.height1').height();
   $('.login_Page').css('height',winHeight);
      $('.login_Page').css('width',winWidth);

/*  $('.login_body').ripples('updateSize')
   $('.height1 .container-fluid').css('height',height1);
  $('.login_Page .row').css('height',winHeight);*/

});


//$(".btn, button").ripple();




/*
$('.login_body').ripples({
                            resolution: 512,
                            dropRadius: 20,
                            perturbance: 0.04,
                        });

*/





function footerBottom(){
    bottomHeight=$(window).height()- $('body').height() - 39;
           if($(window).height()>$('body').height()){
                $('.pagefooter').css('bottom','-'+bottomHeight+'px');
           }
}


/*For Login Page End*/
