<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./plugins/bootstrap/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/animate.css" crossorigin="anonymous">
    <link rel="stylesheet" href="./plugins/fontawesome/css/all.css" crossorigin="anonymous">
    <link rel="stylesheet" href="./plugins/select2/css/select2.css" crossorigin="anonymous">
    <link rel="stylesheet" href="./plugins/bootstrap-select/css/bootstrap-select.css" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/custom.css" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/applicationPage.css" crossorigin="anonymous">

    <title>MUFG Application Page</title>
<style>


</style>


</head>

<body class="appList_body">


<nav class="navbar navbar-expand-lg navbar-dark bgPink border-bottom shadow-sm">
  <a class="navbar-brand" href="#"><img src="./img/logo_horizontal.png" class="img-fluid img-responsive" width="130"></a>
  
 
<a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0 ml-auto" data-toggle="collapse" data-target="#navbarContent">
   <i class="fas fa-bars text-white font1p6 "></i>
  </a>
     <div class="dropdown ml-lg-auto">
                  <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                    <span class="avatar" ><i class="fas fa-female"></i></span>
                    <span class="ml-2 d-none d-lg-inline-block">
                      <span class="text-default text-white font-weight-bold">Rahul Soni</span>
                      <small class="text-muted d-block mt-1">Administrator</small>
                    </span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow avtarDropDown">
                    <a class="dropdown-item" href="#">
                      <i class="dropdown-icon fe fe-user"></i> Profile
                    </a>
                    <a class="dropdown-item" href="#">
                      <i class="dropdown-icon fe fe-settings"></i> Settings
                    </a>
                    <a class="dropdown-item" href="#">
                      <i class="dropdown-icon fe fe-send"></i> Message
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">
                      <i class="dropdown-icon fe fe-help-circle"></i> Need help?
                    </a>
                    <a class="dropdown-item" href="#">
                      <i class="dropdown-icon fe fe-log-out"></i> Sign out
                    </a>
                  </div>
                </div>
    
</nav>
<div class="appMenubar">
<div class="">
    <div class="navbar navbar-expand-lg navbar-light border-bottom shadow-sm " id="navbarContent">
    <ul class=" navbar-nav clrSecondary">
      <li class="nav-item active">
        <a class="nav-link" href="#"> <i class="fas fa-home"></i> Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fas fa-plug"></i> Link</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fas fa-plug"></i>  Something Here
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#"><i class="fas fa-plug"></i> Action</a>
          <a class="dropdown-item" href="#"><i class="fas fa-plug"></i> Action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#"> <i class="fas fa-plug"></i> Something else here</a>
        </div>
      </li>
    <li class="nav-item ">
        <a class="nav-link" href="#"> <i class="fas fa-home"></i> Something <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fas fa-plug"></i>  Something Here
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#"><i class="fas fa-plug"></i> Action</a>
          <a class="dropdown-item" href="#"><i class="fas fa-plug"></i> Action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#"> <i class="fas fa-plug"></i> Something else here</a>
        </div>
      </li>
    
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fas fa-plug"></i> Link</a>
      </li>
    </ul>

    <div class="ml-auto">
      <span class="font1 clrDanger ">Password Expired in : <span id="passWordExpiryDate" class=""> </span></span>
  </div>
  </div>
  </div>


</div>
<section class="">
    <div class="container">
        <div class="row pt-5">
            <div class="form-group col-lg">
              <div class="input-search  animated fadeIn">
                <button type="submit" class="input-search-btn"><i class="fas fa-search clrSecondary clrSecondary" aria-hidden="true"></i></button>
                <input type="text" class="form-control shadow-sm py-3" name="" placeholder="Search..." id="searchApps">
              </div>
            </div>
        </div>    
        <div class="container mt-5 pb-3 border-bottom borderclrSecondary clrSecondary  animated fadeIn">
            <div class="">
            <h5 class=" h5 text-left float-left d-inline-block">Please Choose Application to Work Upon </h5> 
            <h5 class="text-right  float-right d-inline-block"> Total Application : <span class="borderclrGray clrPink font-weight-bold font1p8 px-2 rounded-circle border-width3px" id="totalAppsNumber"> 7 </span>  </h5>
            <div class="clearfix"></div>
        </div>
        </div> 
        <div class="container my-5 appsListContainer">
            <div class="row rounded shadow appListAppsLogin mb-5 animated fadeInLeft">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/short_loan.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">Short Term Loan</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Checker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div>  

            <div class="row rounded shadow mb-5 appListAppsNonLogin  animated fadeInRight">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/gst.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">G.S.T.</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Maker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div>  

            <div class="row rounded shadow mb-5 appListAppsNonLogin  animated fadeInLeft">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/npa.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">N.P.A.</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Checker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div> 

            <div class="row rounded shadow mb-5 appListAppsLogin  animated fadeInRight">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/money_market.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">Money Market</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Checker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div>            
       
            <div class="row rounded shadow mb-5 appListAppsLogin  animated fadeInLeft">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/spend_management.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">Money Market</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Maker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div>                    
       
            <div class="row rounded shadow mb-5 appListAppsNonLogin  animated fadeInRight">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/mromakate.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">Mr. Omakate</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Maker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div>                             
       
            <div class="row rounded shadow mb-5 appListAppsNonLogin  animated fadeInLeft">
                <div class="col border px-2 py-4  align-items-center appListAppName rounded-left">
                  <div class="">
                    <img src="./img/bps.svg" width="60" class="img-fluid img-responsive mx-auto d-table">
                     <h5 class="clrPink font1 font-weight-bold text-center">R.P.S.</h5>
               
                </div>
                </div>
                <div class="col border px-2 py-4  align-items-center appListAppLogin">
                    <div class="mx-auto d-table">
                    <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Last Login</h5>
                    <h5 class="text-left font1p1 clrGray">13-07-2018 18:55:55</h5>
                    </div>
                </div>
                <div class="col border px-2 py-4  align-items-center applistBranchSelect">
                    <div class=" ml-4">
                    <h5 class="clrPink font0p8 text-left">Select Branch</h5>
                     <select class="select2select w-75" id="">
                        <option value="" readonly disabled="disabled" selected="">Choose...</option>
                        <option value="1">Mumbai</option>
                        <option value="2">Delhi</option>
                        <option value="3">Chennai</option>
                     </select>
                </div>
                </div>
                <div class="col border px-2 py-4 align-items-center appListAppRole">
                    <div class="mx-auto d-table">
                     <h5 class="clrPink font0p8 text-left mb-0">&nbsp;Role</h5>
                    <h5 class="text-left clrSecondary ">Checker</h5>
                </div>
                </div>
                <div class="col border px-2 py-4 appListAppView rounded-right">
                    <div class="px-2">
                    <button type="button" class="btn btn-success bgSuccess btn-block rounded-0 outline-0 shadow-none mt-3 btnHoverSecBorder"><i class="far fa-eye font1p2 pt-0p15 float-right"></i> &nbsp; View </button>  
                </div>
                </div>
            </div>            
        </div>  
         
    </div>
</section>


<section class="mb-4">
  <div class="container-fluid mt-6">
                <div class="row align-items-center h-100 p-0">
                    <div class="col-7   height1 mx-auto">

                        <div class="card  border shadow container-fluid position-relative animated fadeIn">
                            <div class="height600px row" >
                                <div class="mouth-container ">
                                      <div class="circle">
                                        <div class="drops"></div>
                                        <div class="drops"></div>
                                        <div class="hand"></div>
                                        <div class="hand rgt"></div>
                                        <div class="holder">
                                          <div class="bob">
                                            <div class="nose"></div>
                                            <div class="face">
                                              <div class="mouth">
                                                <div class="tongue"></div>
                                              </div>
                                            </div>
                                            <div class="ear"></div>
                                            <div class="ear rgt"></div>
                                            <div class="neck"></div>
                                          </div>
                                        </div>
                                      </div>  
                                      
                                    </div>
                                    <div class="container-fluid margintp350">
                                        <div class="row py-4">
                                        <h2 class="my-4 text-center clrPink font4 font-weight-bold w-100"><i class="far fa-sad-tear clrSecondary  font3"></i>&nbsp;!!Oops!!&nbsp;<i class="far fa-sad-tear clrSecondary  font3"></i></h2>
                                        <h3 class=" text-center  clrSecondary w-100">You are not Authenticate for Any Application</h3>
                                        </div>
                                    </div>
                                     
                                
                                <div class="appListCardNonLoginfooter cardfooter-Text text-center clrViolet">Contact Customer Care : <a href="tel:+91-022-1254582" class="clrPink">+91-022-1254582</a></div>
                            </div><!--  height600px-->
                        </div> <!-- .card border-0  -->
                     </div><!-- .col-8   height1 mx-auto -->
                </div><!-- .row align-items-center h-100 p-0 -->
         </div><!-- .container-fluid login_Page -->
 </section>


<footer class="border-top borderclrSecondary position-absolute w-100 bottom-0 appsListFooter">
    <div class="font0p8 text-center clrGray">* This Website is Only Accessible for <span class="clrPink">MUFG </span> Employee And if any other person seen using this application will be punished .</div>
    <div  class="font0p8 text-center clrGray"> * All Right Reserved to <span class="clrPink">MUFG </span> </div>
</footer>
<div class="bottomScroller">
    <div class="rounded clrSuccess  p3  arrowUp cursorPointer"  onmouseover="scrollUp();"><i class="fas fa-arrow-circle-up " ></i></div>
    <div class="rounded  p3 clrSuccess  arrowDown cursorPointer" onmouseover="scrollDown();"><i class="fas fa-arrow-circle-down" ></i></div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./js/jquery-3.3.1.min.js" crossorigin="anonymous"></script>
    <script src="./plugins/bootstrap/js/popper.min.js" crossorigin="anonymous"></script>
    <script src="./plugins/bootstrap/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script src="./plugins/fontawesome/js/all.js" crossorigin="anonymous"></script>
   <script src="./plugins/particles.min.js" crossorigin="anonymous"></script>
   <script src="./plugins/select2/js/select2.min.js" crossorigin="anonymous"></script>
   <script src="./plugins/bootstrap-select/js/bootstrap-select.min.js" crossorigin="anonymous"></script>
   <script src="./plugins/waypoint/jquery.waypoints.min.js" crossorigin="anonymous"></script>
    <script src="./js/custom.js" crossorigin="anonymous"></script>
    <script src="./js/applicationPage.js" crossorigin="anonymous"></script>
    <script src="./js/particle_Canvas.js" crossorigin="anonymous"></script>


</body>

</html>